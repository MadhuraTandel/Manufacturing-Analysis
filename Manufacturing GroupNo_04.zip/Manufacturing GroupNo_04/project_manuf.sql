select * from prod_data;

SELECT CONCAT(Emp_Name, ' - ', Emp_Code) AS Emp_Details, SUM(Rejected_Qty) AS Total_Rejected
FROM prod_data
GROUP BY Emp_Code, Emp_Name
ORDER BY Total_Rejected desc limit 10;   -- top 10 Employee wise Rejected qty

SELECT Machine_Name, SUM(Rejected_Qty) AS Total_Rejected
FROM prod_data
GROUP BY Machine_Name
ORDER BY Total_Rejected desc;   -- Machine wise rejected qty

SELECT Operation_Name, SUM(Rejected_Qty) AS Total_Rejected
FROM prod_data
GROUP BY Operation_Name
ORDER BY Total_Rejected desc;    -- Operation wise rejected qty

SELECT Department_Name, 
       SUM(Manufactured_Qty) AS Total_Manufactured, 
       SUM(Rejected_Qty) AS Total_Rejected
FROM prod_data
GROUP BY Department_Name;       -- Department wise manufacture vs rejected qty



